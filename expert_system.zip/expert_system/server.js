const express = require('express');
const fs = require('fs');
const app = express();
const port = 3000;
app.use(express.json());

// Load question-answer data from JSON file
const qaData = JSON.parse(fs.readFileSync('qa.json', 'utf8'));

// Function to find matching question and return corresponding answer
async function runChat(userInput) {
  const matchingQuestion = qaData.find(qa => userInput.toLowerCase().includes(qa.question.toLowerCase()));
  const response = matchingQuestion ? matchingQuestion.answer : "Sorry, I don't understand that question.";

  return response;
}

app.get('/', (req, res) => {
  res.sendFile(__dirname + '/index.html');
});

app.get('/loader.gif', (req, res) => {
  res.sendFile(__dirname + '/loader.gif');
});

app.post('/chat', async (req, res) => {
  try {
    const userInput = req.body?.userInput;
    console.log('Incoming /chat request. User input:', userInput)
    if (!userInput) {
      return res.status(400).json({ error: 'Invalid request body' });
    }

    const response = await runChat(userInput);
    res.json({ response });
  } catch (error) {
    console.error('Error in chat endpoint:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

app.listen(port, () => {
  console.log(`Server listening on port ${port}`);
});
